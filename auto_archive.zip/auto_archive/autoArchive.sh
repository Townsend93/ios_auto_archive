#!/bin/sh

#xcodebuild clean -workspace Fuse.xcworkspace -scheme Fuse -configuration Release

#xcodebuild archive -workspace Fuse.xcworkspace -scheme Fuse -configuration Release -archivePath /Desktop/Fuse/FuseSwift/FuseSwift.xcarchive

#xcodebuild -exportArchive -archivePath (xcarchivepath) -exportPath destinationpath -exportOptionsPlist path

# archive resign

#security cms -D -i embedded.mobileprovision > entitlements_full.plist

#/usr/libexec/PlistBuddy -x -c 'Print:Entitlements' entitlements_full.plist > entitlements.plist


# ******** 变量配置 *********

# 开始时间
beginTime=`date +%s`

#开发者账号，密码
appleId="xxx@apple.com"
applePsw="123456"

#fir平台的token
fir_token="adasdasd"

# 工程绝对路径
project_path=$(cd `dirname $0`; pwd)

# 当前执行脚本的时间
date=`date +%Y%m%d%H%M`

# 项目名称
project_name="FUSE"

# 工作空间名称
workspace_name="FUSEPRO"

# 打包方式 1:app-store, 2:ad-hoc
method="adhoc"

#build文件夹路径
build_path=${project_path}/build

#exportOptionsPlist 路径
export_options_plist_path=${project_path}/ExportOptionsAdHoc.plist

# 所有的target名称
schemes=("FUSE-Staging" "FUSE-Testing")

# target里的配置
configurations=("Release")

# archivePath
archive_path=${build_path}/${project_name}.xcarchive

# ipa 目录
ipa_path="~/desktop/temp_ipa/${date}"

# ********* 开始打包 *************

# 询问需要什么包
echo "Place enter the number you want to export ? [ 1:app-store 2:ad-hoc] "

read number
while([[ $number != 1 ]] && [[ $number != 2 ]])
do
echo "Error! Should enter 1 or 2"
echo "Place enter the number you want to export ? [ 1:app-store 2:ad-hoc] "
read number
done

if [ $number == 1 ];then
schemes=("FUSE")
configurations=("Release")
method="appstore"
export_options_plist_path=${project_path}/ExportOptionsAppStore.plist
else
method="adhoc"
export_options_plist_path=${project_path}/ExportOptionsAdHoc.plist
fi

#遍历schemes
for scheme in ${schemes[@]};
do

#遍历configurations
for configuration in ${configurations[@]};
do

# 更新打包时间
date=`date +%Y%m%d%H%M`

# ipa 名称
ipa_name="${date}_${method}_${project_name}_${configuration}.ipa"

#step 1: clean
xcodebuild clean -workspace ${workspace_name}.xcworkspace \
-scheme ${scheme} \
-configuration ${configuration} \
#-quiet || exit

#step 2: archive
xcodebuild archive -workspace ${workspace_name}.xcworkspace \
-scheme ${scheme} \
-configuration ${configuration} \
-archivePath ${archive_path} \
#-quiet || exit

#step 3: export
xcodebuild -exportArchive -archivePath ${archive_path} \
-configuration ${configuration} \
-exportPath ${ipa_path}/${ipa_name} \
-exportOptionsPlist ${export_options_plist_path} \
#-quiet || exit

done

done

# 清除缓存
rm -rf ${build_path}


# 结束时间
endTime=`date +%s`
echo -e "打包时间$[ endTime - beginTime ]秒"


